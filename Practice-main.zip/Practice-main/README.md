# Automation_Practice
## Project Name:
#### Nopcommerce.
### The main Frameworks included in the project:
- Selenium Webdriver
- TestNG
- Allure Report
### Project Design:
- Page Object Model (POM)
- Data Driven framework
- Fluent design
- At every package in the main package, you will find two types of classes: one for the actions and another to call these actions, and this class is called scenario + the page name.